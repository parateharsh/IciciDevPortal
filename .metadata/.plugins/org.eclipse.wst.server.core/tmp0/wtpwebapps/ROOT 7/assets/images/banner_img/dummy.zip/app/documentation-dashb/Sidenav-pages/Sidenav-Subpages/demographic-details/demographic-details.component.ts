import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demographic-details',
  templateUrl: './demographic-details.component.html',
 // styleUrls: ['./demographic-details.component.css']
})
export class DemographicDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
