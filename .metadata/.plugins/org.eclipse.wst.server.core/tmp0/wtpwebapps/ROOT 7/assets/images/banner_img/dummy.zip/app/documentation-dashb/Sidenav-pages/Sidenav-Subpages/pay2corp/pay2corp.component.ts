import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay2corp',
  templateUrl: './pay2corp.component.html',
  //styleUrls: ['./pay2corp.component.css']
})
export class Pay2corpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
