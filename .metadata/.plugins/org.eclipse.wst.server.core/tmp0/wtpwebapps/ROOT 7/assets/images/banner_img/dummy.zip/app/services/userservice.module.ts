import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LoginService } from './login.service';
@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
  ],
  entryComponents: [

  ],
  providers: [
    LoginService
  ]
})

export class UserservicesModule {
}
