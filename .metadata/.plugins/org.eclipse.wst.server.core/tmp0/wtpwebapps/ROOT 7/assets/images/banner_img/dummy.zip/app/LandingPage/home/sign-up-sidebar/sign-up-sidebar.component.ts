import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-sidebar',
  templateUrl: './sign-up-sidebar.component.html',
  styleUrls: ['./sign-up-sidebar.component.css']
})
export class SignUpSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
