import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountservices',
  templateUrl: './accountservices.component.html',
  //styleUrls: ['./accountservices.component.css']
})
export class AccountservicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
