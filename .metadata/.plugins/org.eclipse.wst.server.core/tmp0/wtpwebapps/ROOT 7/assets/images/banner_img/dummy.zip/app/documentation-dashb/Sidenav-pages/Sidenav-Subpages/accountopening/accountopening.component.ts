import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountopening',
  templateUrl: './accountopening.component.html',
  //styleUrls: ['./accountopening.component.css']
})
export class AccountopeningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
