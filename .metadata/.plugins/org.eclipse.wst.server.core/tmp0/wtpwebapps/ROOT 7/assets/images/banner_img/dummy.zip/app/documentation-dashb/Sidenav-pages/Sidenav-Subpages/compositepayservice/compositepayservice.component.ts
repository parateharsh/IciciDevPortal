import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compositepayservice',
  templateUrl: './compositepayservice.component.html',
 // styleUrls: ['./compositepayservice.component.css']
})
export class CompositepayserviceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
