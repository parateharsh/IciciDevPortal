import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-authentication',
  templateUrl: './customer-authentication.component.html',
  //styleUrls: ['./customer-authentication.component.css']
})
export class CustomerAuthenticationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
